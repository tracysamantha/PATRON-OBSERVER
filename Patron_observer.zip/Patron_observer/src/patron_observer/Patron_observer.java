/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package patron_observer;

/**
 *
 * @author JAIRO
 */
public class Patron_observer {

    public static void main(String[] args) {
        // Crear la plataforma del clima
        PlataformaClima plataformaClima = new PlataformaClima();

        // Crear los observadores
        DUENDE duende1 = new DUENDE("Duende Verde");
        OGRO ogro = new OGRO("Shrek");

        // Añadir los observadores a la plataforma
        plataformaClima.addObserver(duende1);
        plataformaClima.addObserver(ogro);

        // Cambiar el clima y notificar a los observadores
        plataformaClima.setClima("Soleado");
        plataformaClima.setClima("Lluvioso");
    }
}