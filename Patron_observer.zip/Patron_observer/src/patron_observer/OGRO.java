/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patron_observer;

public class OGRO implements Observer {
    private String nombre;

    public OGRO (String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void update(String clima) {
        System.out.println(nombre + " ha sido notificado del nuevo clima: " + clima);
    }
}