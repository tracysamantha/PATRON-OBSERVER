/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patron_observer;

import java.util.ArrayList;
import java.util.List;

class PlataformaClima implements Subject {
    private List<Observer> observers;
    private String clima;

    public PlataformaClima() {
        observers = new ArrayList<>();
    }

    @Override
    public void addObserver(Observer o) {
        observers.add(o);
    }

    @Override
    public void removeObserver(Observer o) {
        observers.remove(o);
    }

    @Override
    public void notifyObservers() {
        for (Observer o : observers) {
            o.update(clima);
        }
    }

    public void setClima(String nuevoClima) {
        this.clima = nuevoClima;
        notifyObservers();
    }
}
